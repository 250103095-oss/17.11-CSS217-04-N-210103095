public class Main {
    public static void main(String[] args) {
        FlightBookingFacade bookingFacade = new FlightBookingFacade();

        System.out.println("=== TEST 1: Standard Successful Booking ===");
        String ticket1 = bookingFacade.bookFlight(
                "Amina Suleimenova", "KC101", "14A", 320.00, 2, 23.0, "EUR", "4532015112830366");
        System.out.println("Result 1: " + ticket1 + "\n");

        System.out.println("=== TEST 2: Blocked Crew Seat (Row 13) ===");
        String ticket2 = bookingFacade.bookFlight("Daniyar Kassymov", "KC101", "13C", 320.00, 1, 15.0, "USD", "4532015112830366");
        System.out.println("Result 2: " + ticket2 + "\n");

        System.out.println("=== TEST 3: Payment Failure & Automatic Seat Rollback ===");
        String ticket3 = bookingFacade.bookFlight("Timur Bekov", "KC101", "07D", 320.00, 1, 18.0, "KZT", "9999");
        System.out.println("Result 3: " + ticket3 + "\n");

        System.out.println("=== TEST 4: SILVER Tier (no baggage fee + promo) ===");
        String ticket4 = bookingFacade.bookFlight("Aigerim Nurlanova", "KC101", "15F", 320.00, 3, 30.0, "USD", "4532015112830366", "SILVER");
        System.out.println("Result 4: " + ticket4 + "\n");

        System.out.println("=== SCENARIO A: Valid Booking (14B, KZ204, EUR) ===");
        System.out.println("Result A: " + bookingFacade.bookFlight("Aruzhan Omarova", "KZ204", "14B", 250.00, 2, 24.5, "EUR", "4532015112830366") + "\n");

        System.out.println("=== SCENARIO B: Blocked Seat 13A ===");
        System.out.println("Result B: " + bookingFacade.bookFlight("Nurlan Abenov", "KZ204", "13A", 250.00, 1, 10.0, "USD", "4532015112830366") + "\n");

        System.out.println("=== SCENARIO C: Rollback (08C, card 1234) ===");
        System.out.println("Result C: " + bookingFacade.bookFlight("Dana Serikova", "KZ204", "08C", 250.00, 1, 18.0, "USD", "1234") + "\n");
    }
}